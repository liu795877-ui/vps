"""Compose the audited service rules using only the existing private VPS nodes."""

import copy
import json
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).parent
MODES = ("manual", "services")


def preset():
    return json.loads((ROOT / "services-routing.json").read_text(encoding="utf-8"))


def render(profile, nodes, domains, mode, origin="https://api.aiuzh.icu", base_path="/node-console/"):
    rules = ["DOMAIN,api.ipify.org,STATIC-SELECT"] + [
        "DOMAIN-SUFFIX," + domain + ",STATIC-SELECT" for domain in domains
    ]
    if mode == "manual":
        return profile.split("\nrules:\n", 1)[0] + "\nrules:\n" + "".join(
            "  - " + json.dumps(rule, ensure_ascii=False) + "\n" for rule in rules + ["MATCH,DIRECT"]
        )
    if mode != "services":
        raise ValueError("Unknown routing mode.")
    data = preset()
    groups = [{"name": "STATIC-SELECT", "type": "select", "proxies": [node["name"] for node in nodes]}] + data["groups"]
    providers = copy.deepcopy(data["providers"])
    for item in providers.values():
        resource = item.pop("resource", None)
        if resource:
            item["url"] = origin.rstrip("/") + base_path + "rules/" + resource
        parsed = urlsplit(item["url"])
        if parsed.scheme not in ("https", "http") or parsed.username or parsed.password or parsed.query:
            raise ValueError("Rule provider URL contains unsupported private parameters.")
    fields = {"proxy-groups": groups, "rule-providers": providers, "dns": data["dns"],
              "profile": data["profile"], "unified-delay": data["unified-delay"],
              "rules": rules + data["rules"]}
    prefix = profile.split("\nproxy-groups:\n", 1)[0]
    prefix = prefix.replace("# Example rules only: GitHub and the IP check use VPS; other sites are direct.",
                            "# Service routing: original rule order; service groups control proxy/direct routing.")
    return prefix + "\n" + "".join(key + ": " + json.dumps(value, ensure_ascii=False) + "\n"
                                      for key, value in fields.items())
